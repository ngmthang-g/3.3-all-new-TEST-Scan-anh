from pathlib import Path


def read(path):
    return Path(path).read_text(encoding="utf-8")


def write(path, text):
    Path(path).write_text(text, encoding="utf-8")


def replace_once(path, old, new):
    text = read(path)
    if old not in text:
        if new in text:
            return
        raise RuntimeError(f"anchor missing in {path}: {old[:120]!r}")
    if text.count(old) != 1:
        raise RuntimeError(f"anchor not unique in {path}: count={text.count(old)} {old[:120]!r}")
    write(path, text.replace(old, new, 1))


def replace_region(path, start_marker, end_marker, new_region):
    text = read(path)
    start = text.find(start_marker)
    if start < 0:
        if new_region.strip() in text:
            return
        raise RuntimeError(f"start marker missing in {path}: {start_marker}")
    end = text.find(end_marker, start)
    if end < 0:
        raise RuntimeError(f"end marker missing in {path}: {end_marker}")
    write(path, text[:start] + new_region.rstrip() + "\n\n    " + text[end:])


def replace_in_region(path, start_marker, end_marker, old, new):
    text = read(path)
    start = text.find(start_marker)
    end = text.find(end_marker, start if start >= 0 else 0)
    if start < 0 or end < 0:
        raise RuntimeError(f"region missing in {path}: {start_marker} -> {end_marker}")
    region = text[start:end]
    if old not in region:
        if new in region:
            return
        raise RuntimeError(f"regional anchor missing in {path}/{start_marker}: {old[:120]!r}")
    region = region.replace(old, new, 1)
    write(path, text[:start] + region + text[end:])


# -----------------------------------------------------------------------------
# Protocol: v4.5 activity-board observer is controller/bridge ABI-visible.
# -----------------------------------------------------------------------------
replace_once("src/protocol.h", "constexpr std::uint32_t kProtocolVersion = 0x00040200u;",
             "constexpr std::uint32_t kProtocolVersion = 0x00040500u;")
replace_once("src/protocol.h", "    ReadDungeonProgress = 27,\n};",
             "    ReadDungeonProgress = 27,\n    ReadDungeonActivityBoard = 28,\n};")
activity_protocol = r'''
constexpr std::size_t kMaxDungeonActivityObjectives = 24;

struct DungeonActivityObjectiveSnapshot {
    std::int32_t current = -1;
    std::int32_t target = -1;
    std::int32_t objectiveId = 0;
    wchar_t name[128]{};
};

struct DungeonActivitySnapshot {
    std::uint32_t validMask = 0;
    std::int32_t synchronized = 0;
    std::int32_t activityId = 0;
    std::int32_t mapID = 0;
    std::int32_t remainingSeconds = -1;
    std::uint64_t capturedTick = 0;
    std::uint32_t objectiveCount = 0;
    wchar_t activityName[96]{};
    wchar_t source[64]{};
    DungeonActivityObjectiveSnapshot objectives[kMaxDungeonActivityObjectives]{};
};

'''
replace_once("src/protocol.h", "struct Response {\n", activity_protocol + "struct Response {\n")
replace_once("src/protocol.h", "    DungeonProgressSnapshot dungeonProgress{};\n",
             "    DungeonProgressSnapshot dungeonProgress{};\n    DungeonActivitySnapshot dungeonActivity{};\n")

# -----------------------------------------------------------------------------
# Bridge: live active-UI activity board, fail closed and never fabricate counters.
# -----------------------------------------------------------------------------
replace_once("src/bridge.cpp", "#include <cstring>\n", "#include <cstring>\n#include <cwctype>\n")
replace_once("src/bridge.cpp", "void ProcessRequest() {\n",
             "#include \"dungeon_activity_bridge.inl\"\n\nvoid ProcessRequest() {\n")
replace_once("src/bridge.cpp",
             "            case Command::ReadDungeonProgress:\n                ok = ReadDungeonProgress(r, detail, _countof(detail)); break;\n",
             "            case Command::ReadDungeonProgress:\n                ok = ReadDungeonProgress(r, detail, _countof(detail)); break;\n"
             "            case Command::ReadDungeonActivityBoard:\n"
             "                ok = ReadDungeonActivityBoard(g_shared->request.arg0, r, detail, _countof(detail)); break;\n")

# -----------------------------------------------------------------------------
# Base dungeon contract: v4.5 queue entries allow up to 10 repeats.
# -----------------------------------------------------------------------------
replace_once("src/dungeon_logic.h",
             "    if (team.runs < 1 || team.runs > 3) {\n        error = L\"Số lượt phải 1–3\";",
             "    if (team.runs < 1 || team.runs > 10) {\n        error = L\"Số lượt phải 1–10\";")

# -----------------------------------------------------------------------------
# Controller declarations / ownership / commands.
# -----------------------------------------------------------------------------
replace_once("src/controller.cpp", '#include "dungeon_logic.h"\n#include "dungeon_presets.h"',
             '#include "dungeon_logic.h"\n#include "dungeon_v45_logic.h"\n#include "dungeon_presets.h"')
replace_once("src/controller.cpp", 'constexpr wchar_t kTitle[] = L"AUTO Thần Long đa tính năng Pro v4.4";',
             'constexpr wchar_t kTitle[] = L"AUTO Thần Long đa tính năng Pro v4.5";')
replace_once("src/controller.cpp",
             "constexpr int IDC_DG_SAVE_MONSTER=722;\n// Dungeon preset editor window (740-779 reserved).",
             "constexpr int IDC_DG_SAVE_MONSTER=722;\n"
             "constexpr int IDC_DG_ACTIVITY_BOARD=723;\n"
             "constexpr int IDC_DG_TEAM_MANAGER=724;\n"
             "constexpr int IDC_DG_EXPORT_ALL=725;\n"
             "constexpr int IDC_DG_IMPORT_ALL=726;\n"
             "// Dungeon preset editor window (740-779 reserved).")
replace_once("src/controller.cpp",
             "constexpr int IDC_DGE_LIST=740;",
             "// v4.5 team/queue manager window (780-799 reserved).\n"
             "constexpr int IDC_DGM_NAME=780;\n"
             "constexpr int IDC_DGM_MEMBERS=781;\n"
             "constexpr int IDC_DGM_LEADER=782;\n"
             "constexpr int IDC_DGM_UPDATE_TEAM=783;\n"
             "constexpr int IDC_DGM_QUEUE=784;\n"
             "constexpr int IDC_DGM_PRESET=785;\n"
             "constexpr int IDC_DGM_RUNS=786;\n"
             "constexpr int IDC_DGM_QUEUE_ADD=787;\n"
             "constexpr int IDC_DGM_QUEUE_UPDATE=788;\n"
             "constexpr int IDC_DGM_QUEUE_DELETE=789;\n"
             "constexpr int IDC_DGM_QUEUE_UP=790;\n"
             "constexpr int IDC_DGM_QUEUE_DOWN=791;\n\n"
             "constexpr int IDC_DGE_LIST=740;")
replace_once("src/controller.cpp",
             "    std::set<std::uint32_t> postSellDone{};\n    std::wstring status = L\"STOP\";\n};",
             "    std::set<std::uint32_t> postSellDone{};\n"
             "    // v4.5 persistent plan identity; queue runtime indices reset at START.\n"
             "    std::wstring displayName{};\n"
             "    std::vector<dungeon_v45::QueueEntry> queue{};\n"
             "    int queueIndex = 0;\n"
             "    int queueRunIndex = 1;\n"
             "    std::vector<std::wstring> completionNotifyKeys{};\n"
             "    std::wstring status = L\"STOP\";\n};")
replace_once("src/controller.cpp",
             "    std::vector<DungeonTeamRuntime> dungeonTeams_{};\n    int dungeonNextTeamId_=1;\n",
             "    std::vector<DungeonTeamRuntime> dungeonTeams_{};\n    int dungeonNextTeamId_=1;\n"
             "    // v4.5 modeless windows are kept outside the dense tab surface.\n"
             "    HWND dungeonActivityWindow_=nullptr;\n"
             "    HWND dungeonActivityTitle_=nullptr;\n"
             "    HWND dungeonActivityList_=nullptr;\n"
             "    HWND dungeonActivityStatus_=nullptr;\n"
             "    DWORD dungeonActivityLastTick_=0;\n"
             "    HWND dungeonManagerWindow_=nullptr;\n"
             "    HWND dungeonManagerName_=nullptr;\n"
             "    HWND dungeonManagerStatus_=nullptr;\n"
             "    HWND dungeonManagerMembers_=nullptr;\n"
             "    HWND dungeonManagerLeader_=nullptr;\n"
             "    HWND dungeonManagerQueue_=nullptr;\n"
             "    HWND dungeonManagerPreset_=nullptr;\n"
             "    HWND dungeonManagerRuns_=nullptr;\n")
replace_once("src/controller.cpp", '#include "dungeon_app_methods.inl"\n',
             '#include "dungeon_app_methods.inl"\n#include "dungeon_v45_methods.inl"\n')
replace_once("src/controller.cpp",
             "                    case IDC_DG_CONFIG: OpenDungeonEditor(); break;\n                    case IDC_DG_SAVE_THRESHOLD:",
             "                    case IDC_DG_CONFIG: OpenDungeonEditor(); break;\n"
             "                    case IDC_DG_ACTIVITY_BOARD: OpenDungeonActivityBoard(); break;\n"
             "                    case IDC_DG_TEAM_MANAGER: OpenDungeonTeamManager(); break;\n"
             "                    case IDC_DG_EXPORT_ALL: ExportDungeonAllConfig(); break;\n"
             "                    case IDC_DG_IMPORT_ALL: ImportDungeonAllConfig(); break;\n"
             "                    case IDC_DG_SAVE_THRESHOLD:")
replace_once("src/controller.cpp", "        mainTabIndex_ = index;\n    }\n\n    bool IsCompactKeepControl",
             "        mainTabIndex_ = index;\n        DungeonV45OnMainTabChanged(index);\n    }\n\n    bool IsCompactKeepControl")
replace_once("src/controller.cpp",
             "        TickAutoPk(GetTickCount());\n        if (!globalPaused_) TickDungeon(GetTickCount());\n",
             "        TickAutoPk(GetTickCount());\n        const DWORD dungeonNow = GetTickCount();\n        if (!globalPaused_) TickDungeon(dungeonNow);\n        RefreshDungeonActivityBoard(false, dungeonNow);\n")

# -----------------------------------------------------------------------------
# v4.5 methods: one compile fix + layout that never overlays the existing tab UI.
# -----------------------------------------------------------------------------
replace_once("src/dungeon_v45_methods.inl",
             "        const int runs = ParseInt(GetText(dungeonManagerRuns_), 1);",
             "        const int runs = ParseEditInt(dungeonManagerRuns_, 1, 1, dungeon_v45::kMaxRunsPerEntry);")
text = read("src/dungeon_v45_methods.inl")
marker = "    void DungeonV45CreateMainControls() {"
start = text.find(marker)
if start < 0:
    raise RuntimeError("DungeonV45CreateMainControls missing")
new_tail = r'''    void DungeonV45CreateMainControls() {
        // Reserve the last two rows for v4.5 controls. Move the old safety note down instead of
        // painting over it; this is the same no-overlap rule used for ACC BÁO CÁO.
        for (HWND h : dungeonControls_) {
            if (!h) continue;
            wchar_t text[256]{};
            GetWindowTextW(h, text, _countof(text));
            if (wcsncmp(text, L"An toàn:", 7) == 0) {
                MoveWindow(h, 18, 966, 1005, 30, TRUE);
                break;
            }
        }
        DungeonMake(L"BUTTON", L"BẢNG HOẠT ĐỘNG PB", BS_PUSHBUTTON,
                    18, 930, 180, 30, IDC_DG_ACTIVITY_BOARD);
        DungeonMake(L"BUTTON", L"QUẢN LÝ ĐỘI / KẾ HOẠCH", BS_PUSHBUTTON,
                    206, 930, 245, 30, IDC_DG_TEAM_MANAGER);
        DungeonMake(L"BUTTON", L"XUẤT TOÀN BỘ CẤU HÌNH", BS_PUSHBUTTON,
                    459, 930, 220, 30, IDC_DG_EXPORT_ALL);
        DungeonMake(L"BUTTON", L"NHẬP TOÀN BỘ CẤU HÌNH", BS_PUSHBUTTON,
                    687, 930, 220, 30, IDC_DG_IMPORT_ALL);
    }
'''
write("src/dungeon_v45_methods.inl", text[:start] + new_tail)

# -----------------------------------------------------------------------------
# Dungeon app: persistent queue, runtime queue advancement, coordinate inheritance.
# -----------------------------------------------------------------------------
save_fn = r'''    void SaveDungeonTeams() {
        EnsureUnicodeIni();
        const int oldCount = std::clamp(ReadIniInt(L"DungeonTeams", L"Count", 0), 0, 64);
        const int clearCount = std::max(oldCount, static_cast<int>(dungeonTeams_.size()));
        for (int i = 0; i < clearCount; ++i) {
            const std::wstring section = L"DungeonTeam_" + std::to_wstring(i);
            WritePrivateProfileStringW(section.c_str(), nullptr, nullptr, ConfigPath().c_str());
        }
        WriteIniInt(L"DungeonTeams", L"Count", static_cast<int>(dungeonTeams_.size()));
        WriteIniInt(L"DungeonTeams", L"NextId", dungeonNextTeamId_);
        for (std::size_t i = 0; i < dungeonTeams_.size(); ++i) {
            DungeonTeamRuntime& team = dungeonTeams_[i];
            DungeonV45SyncLegacyConfig(team);
            const std::wstring section = L"DungeonTeam_" + std::to_wstring(i);
            if (team.memberRoleIDs.empty()) {
                for (std::uint32_t pid : team.config.pids) {
                    Account* account = AccountByPid(pid);
                    if (account && account->snapshotValid && (account->snapshot.validMask & ValidIdentity))
                        team.memberRoleIDs.push_back(account->snapshot.roleID);
                }
            }
            if (team.leaderRoleID <= 0) {
                Account* leader = AccountByPid(team.config.leaderPid);
                if (leader && leader->snapshotValid && (leader->snapshot.validMask & ValidIdentity))
                    team.leaderRoleID = leader->snapshot.roleID;
            }
            WriteIniInt(section, L"Id", team.config.id);
            WriteIniText(section, L"DisplayName", team.displayName);
            WriteIniInt(section, L"Runs", team.config.runs);
            const int presetIndex = std::clamp(team.config.presetIndex, 0,
                                               std::max(0, static_cast<int>(dungeonPresets_.size()) - 1));
            if (!dungeonPresets_.empty()) WriteIniText(section, L"PresetId", dungeonPresets_[static_cast<std::size_t>(presetIndex)].id);
            WriteIniInt(section, L"LeaderRoleID", team.leaderRoleID);
            WriteIniInt(section, L"MemberCount", static_cast<int>(team.memberRoleIDs.size()));
            for (std::size_t n = 0; n < team.memberRoleIDs.size() && n < cleanroute_dungeon::kMaxTeamMembers; ++n)
                WriteIniInt(section, L"MemberRole_" + std::to_wstring(n), team.memberRoleIDs[n]);
            WriteIniInt(section, L"QueueCount", static_cast<int>(team.queue.size()));
            for (std::size_t q = 0; q < team.queue.size(); ++q) {
                WriteIniText(section, L"QueuePreset_" + std::to_wstring(q), team.queue[q].presetId);
                WriteIniInt(section, L"QueueRuns_" + std::to_wstring(q), team.queue[q].runs);
            }
        }
        FlushIni();
    }'''
replace_region("src/dungeon_app_methods.inl", "    void SaveDungeonTeams() {", "void LoadDungeonTeams() {", save_fn)

load_fn = r'''    void LoadDungeonTeams() {
        dungeonTeams_.clear();
        dungeonNextTeamId_ = std::max(1, ReadIniInt(L"DungeonTeams", L"NextId", 1));
        const int count = std::clamp(ReadIniInt(L"DungeonTeams", L"Count", 0), 0, 32);
        for (int i = 0; i < count; ++i) {
            const std::wstring section = L"DungeonTeam_" + std::to_wstring(i);
            DungeonTeamRuntime team{};
            team.config.id = std::max(1, ReadIniInt(section, L"Id", i + 1));
            team.config.runs = std::clamp(ReadIniInt(section, L"Runs", 1), 1, dungeon_v45::kMaxRunsPerEntry);
            const std::wstring presetId = ReadIniText(section, L"PresetId");
            team.config.presetIndex = FindDungeonPresetById(presetId);
            if (team.config.presetIndex < 0) team.config.presetIndex = 0;
            team.leaderRoleID = ReadIniInt(section, L"LeaderRoleID", 0);
            team.displayName = ReadIniText(section, L"DisplayName");
            if (team.displayName.empty()) team.displayName = L"ĐỘI " + std::to_wstring(team.config.id);
            const int members = std::clamp(ReadIniInt(section, L"MemberCount", 0), 0,
                                           static_cast<int>(cleanroute_dungeon::kMaxTeamMembers));
            for (int m = 0; m < members; ++m) {
                const int roleID = ReadIniInt(section, L"MemberRole_" + std::to_wstring(m), 0);
                if (roleID > 0 && std::find(team.memberRoleIDs.begin(), team.memberRoleIDs.end(), roleID) == team.memberRoleIDs.end())
                    team.memberRoleIDs.push_back(roleID);
            }
            const int queueCount = std::clamp(ReadIniInt(section, L"QueueCount", 0), 0, dungeon_v45::kMaxQueueEntries);
            for (int q = 0; q < queueCount; ++q) {
                const std::wstring id = ReadIniText(section, L"QueuePreset_" + std::to_wstring(q));
                const int runs = std::clamp(ReadIniInt(section, L"QueueRuns_" + std::to_wstring(q), 1), 1, dungeon_v45::kMaxRunsPerEntry);
                if (!id.empty() && FindDungeonPresetById(id) >= 0) team.queue.push_back({id, runs});
            }
            team.queueIndex = 0;
            team.queueRunIndex = 1;
            DungeonV45SyncLegacyConfig(team);
            if (team.memberRoleIDs.empty() || team.queue.empty()) continue;
            team.state = cleanroute_dungeon::TeamState::Stopped;
            team.status = L"Đã nạp cấu hình • chờ quét/bind client";
            dungeonNextTeamId_ = std::max(dungeonNextTeamId_, team.config.id + 1);
            dungeonTeams_.push_back(std::move(team));
        }
    }'''
replace_region("src/dungeon_app_methods.inl", "    void LoadDungeonTeams() {", "void ResolveDungeonTeamBindings() {", load_fn)

replace_once("src/dungeon_app_methods.inl",
             "    cleanroute_dungeon::Preset* DungeonConfiguredPresetForTeam(DungeonTeamRuntime& team) {\n"
             "        if (team.config.presetIndex < 0 || team.config.presetIndex >= static_cast<int>(dungeonPresets_.size())) return nullptr;\n"
             "        return &dungeonPresets_[static_cast<std::size_t>(team.config.presetIndex)];\n"
             "    }\n\n"
             "    const cleanroute_dungeon::Preset* DungeonConfiguredPresetForTeam(const DungeonTeamRuntime& team) const {\n"
             "        if (team.config.presetIndex < 0 || team.config.presetIndex >= static_cast<int>(dungeonPresets_.size())) return nullptr;\n"
             "        return &dungeonPresets_[static_cast<std::size_t>(team.config.presetIndex)];\n"
             "    }",
             "    cleanroute_dungeon::Preset* DungeonConfiguredPresetForTeam(DungeonTeamRuntime& team) {\n"
             "        const int index = DungeonV45PresetIndex(team);\n"
             "        if (index < 0 || index >= static_cast<int>(dungeonPresets_.size())) return nullptr;\n"
             "        return &dungeonPresets_[static_cast<std::size_t>(index)];\n"
             "    }\n\n"
             "    const cleanroute_dungeon::Preset* DungeonConfiguredPresetForTeam(const DungeonTeamRuntime& team) const {\n"
             "        const int index = DungeonV45PresetIndex(team);\n"
             "        if (index < 0 || index >= static_cast<int>(dungeonPresets_.size())) return nullptr;\n"
             "        return &dungeonPresets_[static_cast<std::size_t>(index)];\n"
             "    }")

replace_once("src/dungeon_app_methods.inl",
             "        config.runs = ParseEditInt(dungeonRunsEdit_, 1, 1, 3);",
             "        config.runs = ParseEditInt(dungeonRunsEdit_, 1, 1, dungeon_v45::kMaxRunsPerEntry);")
replace_once("src/dungeon_app_methods.inl",
             "        team.leaderRoleID = leader->snapshot.roleID;\n        team.status = L\"Đã tạo • STOP\";\n        dungeonTeams_.push_back(std::move(team));",
             "        team.leaderRoleID = leader->snapshot.roleID;\n"
             "        team.displayName = L\"ĐỘI \" + std::to_wstring(config.id);\n"
             "        if (config.presetIndex >= 0 && config.presetIndex < static_cast<int>(dungeonPresets_.size()))\n"
             "            team.queue.push_back({dungeonPresets_[static_cast<std::size_t>(config.presetIndex)].id, config.runs});\n"
             "        team.queueIndex = 0; team.queueRunIndex = 1;\n"
             "        team.status = L\"Đã tạo • STOP\";\n"
             "        dungeonTeams_.push_back(std::move(team));")

replace_once("src/dungeon_app_methods.inl",
             "            std::wstring label = L\"ĐỘI \" + std::to_wstring(team.config.id) + L\" • KEY\";",
             "            std::wstring label = DungeonV45TeamLabel(team) + L\" • KEY\";")
replace_once("src/dungeon_app_methods.inl",
             "            std::wstring presetName = preset ? preset->name : L\"?\";\n"
             "            ListView_SetItemText(dungeonTeamList_, visibleRow, 3, presetName.data());\n"
             "            std::wstring runs = std::to_wstring(team.runIndex) + L\"/\" + std::to_wstring(team.config.runs);",
             "            std::wstring presetName = preset ? preset->name : L\"?\";\n"
             "            if (team.queue.size() > 1) presetName += L\" • +\" + std::to_wstring(team.queue.size() - 1);\n"
             "            ListView_SetItemText(dungeonTeamList_, visibleRow, 3, presetName.data());\n"
             "            std::wstring runs = L\"K\" + std::to_wstring(team.queueIndex + 1) + L\"/\" +\n"
             "                                std::to_wstring(std::max<std::size_t>(1, team.queue.size())) + L\" • \" +\n"
             "                                std::to_wstring(team.queueRunIndex) + L\"/\" + std::to_wstring(team.config.runs);")

# Main control row is created only once; add v4.5 controls immediately before initial refresh.
replace_once("src/dungeon_app_methods.inl",
             "        RefreshDungeonAccountList();\n        RefreshDungeonPresetCombo();\n        RefreshDungeonTeamList();\n        RefreshDungeonStepList();\n        RefreshDungeonProgressPanel();\n    }\n\n    void RefreshDungeonAccountList()",
             "        DungeonV45CreateMainControls();\n"
             "        RefreshDungeonAccountList();\n        RefreshDungeonPresetCombo();\n        RefreshDungeonTeamList();\n        RefreshDungeonStepList();\n        RefreshDungeonProgressPanel();\n    }\n\n    void RefreshDungeonAccountList()")

# Queue + inherited-coordinate validation are fail-closed at START.
replace_in_region("src/dungeon_app_methods.inl", "    bool ValidateDungeonStart", "void StartDungeonSelected",
                  "        DungeonTeamRuntime& team = dungeonTeams_[static_cast<std::size_t>(index)];\n        if (!cleanroute_dungeon::ValidateTeam(team.config, error)) return false;",
                  "        DungeonTeamRuntime& team = dungeonTeams_[static_cast<std::size_t>(index)];\n"
                  "        DungeonV45SyncLegacyConfig(team);\n"
                  "        if (!dungeon_v45::ValidateQueue(team.queue, error)) return false;\n"
                  "        if (!cleanroute_dungeon::ValidateTeam(team.config, error)) return false;")
replace_in_region("src/dungeon_app_methods.inl", "    bool ValidateDungeonStart", "void StartDungeonSelected",
                  "        if (team.config.pids.size() < static_cast<std::size_t>(std::max(1, preset->minPlayers))) {",
                  "        if (!dungeon_v45::ValidateInheritedCoordinates(preset->steps, error)) return false;\n"
                  "        if (team.config.pids.size() < static_cast<std::size_t>(std::max(1, preset->minPlayers))) {")

replace_in_region("src/dungeon_app_methods.inl", "    void StartDungeonSelected", "void PauseResumeDungeonSelected",
                  "        std::wstring error;\n        if (!ValidateDungeonStart(index, error)) {",
                  "        if (index >= 0 && index < static_cast<int>(dungeonTeams_.size())) {\n"
                  "            DungeonTeamRuntime& reset = dungeonTeams_[static_cast<std::size_t>(index)];\n"
                  "            if (!cleanroute_dungeon::ActiveState(reset.state)) {\n"
                  "                reset.queueIndex = 0; reset.queueRunIndex = 1; reset.completionNotifyKeys.clear();\n"
                  "                DungeonV45SyncLegacyConfig(reset);\n"
                  "            }\n"
                  "        }\n"
                  "        std::wstring error;\n        if (!ValidateDungeonStart(index, error)) {")
replace_in_region("src/dungeon_app_methods.inl", "    void StartDungeonSelected", "void PauseResumeDungeonSelected",
                  "        team.runIndex = 1;",
                  "        team.runIndex = team.queueRunIndex;")

# Fight radius uses the nearest valid coordinate above on the same map when X/Y are omitted.
replace_once("src/dungeon_app_methods.inl",
             "            if (!observation.verifiedMonster || !cleanroute_dungeon::InRadius(observation, step.x, step.y, step.radius)) continue;",
             "            const auto effectiveCoord = dungeon_v45::ResolveNearestCoordinate(preset->steps, team.stepIndex, step.mapID);\n"
             "            const int centerX = effectiveCoord.valid ? effectiveCoord.x : step.x;\n"
             "            const int centerY = effectiveCoord.valid ? effectiveCoord.y : step.y;\n"
             "            if (!observation.verifiedMonster || !cleanroute_dungeon::InRadius(observation, centerX, centerY, step.radius)) continue;")

# Step list explicitly shows inherited coordinates instead of a misleading dash/0,0.
replace_once("src/dungeon_app_methods.inl",
             "            std::wstring pos = (step.x || step.y) ? std::to_wstring(step.x) + L\",\" + std::to_wstring(step.y) : L\"—\";",
             "            std::wstring pos = dungeon_v45::CoordinateDisplay(display->steps, static_cast<int>(i));")
replace_once("src/dungeon_app_methods.inl",
             "            std::wstring pos = L\"M\" + std::to_wstring(step.mapID) + L\" • \" +\n                               std::to_wstring(step.x) + L\",\" + std::to_wstring(step.y);",
             "            std::wstring pos = dungeon_v45::CoordinateDisplay(preset->steps, static_cast<int>(i));")

# Notify after authoritative map exit, before post-run shared Auto Sell.
replace_once("src/dungeon_app_methods.inl",
             "                RecordDungeonDailyRun(team, *preset);\n                team.phase = cleanroute_dungeon::TeamPhase::PostSell;",
             "                RecordDungeonDailyRun(team, *preset);\n"
             "                DungeonV45NotifyRunComplete(team, *preset);\n"
             "                team.phase = cleanroute_dungeon::TeamPhase::PostSell;")

next_fn = r'''    void BeginDungeonNextRunOrComplete(DungeonTeamRuntime& team, DWORD now) {
        DungeonV45SyncLegacyConfig(team);
        if (team.queue.empty()) {
            FailDungeonTeam(team, L"kế hoạch phó bản rỗng sau PostSell");
            return;
        }

        auto resetForNext = [&](const std::wstring& prefix) {
            team.phase = cleanroute_dungeon::TeamPhase::Gather;
            team.stepIndex = 0;
            team.npcAttempts = 0;
            team.dialogAttempts = 0;
            team.postSellDone.clear();
            ResetDungeonStepRuntime(team, now);
            cleanroute_dungeon::Preset* active = DungeonConfiguredPresetForTeam(team);
            if (!active) {
                FailDungeonTeam(team, L"mất preset ở kế hoạch kế tiếp");
                return false;
            }
            std::wstring inheritedError;
            if (!dungeon_v45::ValidateInheritedCoordinates(active->steps, inheritedError)) {
                FailDungeonTeam(team, inheritedError);
                return false;
            }
            team.activePreset = *active;
            team.activePresetValid = true;
            team.status = prefix + L" • " + active->name + L" • lượt " +
                          std::to_wstring(team.queueRunIndex) + L"/" + std::to_wstring(team.config.runs);
            RefreshDungeonTeamList();
            RefreshDungeonStepList();
            RefreshDungeonProgressPanel(now);
            return true;
        };

        if (team.queueRunIndex < team.config.runs) {
            ++team.queueRunIndex;
            team.runIndex = team.queueRunIndex;
            (void)resetForNext(L"LẶP LẠI KẾ HOẠCH " + std::to_wstring(team.queueIndex + 1));
            return;
        }

        if (team.queueIndex + 1 < static_cast<int>(team.queue.size())) {
            ++team.queueIndex;
            team.queueRunIndex = 1;
            DungeonV45SyncLegacyConfig(team);
            team.runIndex = team.queueRunIndex;
            (void)resetForNext(L"SANG KẾ HOẠCH " + std::to_wstring(team.queueIndex + 1) + L"/" +
                               std::to_wstring(team.queue.size()));
            return;
        }

        const int completedPlans = static_cast<int>(team.queue.size());
        ReleaseDungeonTeamMembers(team);
        team.state = cleanroute_dungeon::TeamState::Completed;
        team.phase = cleanroute_dungeon::TeamPhase::Complete;
        team.status = L"HOÀN THÀNH TOÀN BỘ • " + std::to_wstring(completedPlans) + L" kế hoạch";
        Log(L"AUTO PHÓ BẢN " + DungeonV45TeamLabel(team) + L" COMPLETE ALL QUEUE");
        RefreshDungeonAccountList();
        RefreshDungeonTeamList();
        RefreshDungeonProgressPanel(now);
    }'''
replace_region("src/dungeon_app_methods.inl", "    void BeginDungeonNextRunOrComplete", "void TickDungeonTeam", next_fn)

# Richer progress context for queue/runtime position.
replace_once("src/dungeon_app_methods.inl",
             "        DungeonProgressAdd(L\"Lượt / Phase\", std::to_wstring(team.runIndex) + L\"/\" + std::to_wstring(team.config.runs) + L\" • \" + DungeonPhaseLabel(team.phase));",
             "        DungeonProgressAdd(L\"Kế hoạch / Lượt\", L\"K\" + std::to_wstring(team.queueIndex + 1) + L\"/\" +\n"
             "                           std::to_wstring(std::max<std::size_t>(1, team.queue.size())) + L\" • \" +\n"
             "                           std::to_wstring(team.queueRunIndex) + L\"/\" + std::to_wstring(team.config.runs) + L\" • \" + DungeonPhaseLabel(team.phase));")

# Progress position uses inherited display too (regex-like literal block replacement).
old_progress = """            DungeonProgressAdd(L\"Vị trí\", L\"M\" + std::to_wstring(step.mapID) + L\" • \" + std::to_wstring(step.x) + L\",\" + std::to_wstring(step.y) +\n                               (step.kind == cleanroute_dungeon::StepKind::Fight ? L\" • R\" + std::to_wstring(step.radius) : L\" • Tol \" + std::to_wstring(step.tolerance)));"""
new_progress = """            DungeonProgressAdd(L\"Vị trí\", dungeon_v45::CoordinateDisplay(preset->steps, team.stepIndex) +\n                               (step.kind == cleanroute_dungeon::StepKind::Fight ? L\" • R\" + std::to_wstring(step.radius) : L\" • Tol \" + std::to_wstring(step.tolerance)));"""
replace_once("src/dungeon_app_methods.inl", old_progress, new_progress)

# -----------------------------------------------------------------------------
# Build/version resources.
# -----------------------------------------------------------------------------
replace_once("CMakeLists.txt", "project(ThanLongItemConsolidator VERSION 4.4 LANGUAGES CXX RC)",
             "project(ThanLongItemConsolidator VERSION 4.5 LANGUAGES CXX RC)")
replace_once("CMakeLists.txt",
             "add_executable(dungeon_logic_tests src/dungeon_logic_test.cpp)\ntarget_include_directories(dungeon_logic_tests PRIVATE src)\nadd_executable(travel_network_logic_tests",
             "add_executable(dungeon_logic_tests src/dungeon_logic_test.cpp)\n"
             "target_include_directories(dungeon_logic_tests PRIVATE src)\n"
             "add_executable(dungeon_v45_logic_tests src/dungeon_v45_logic_test.cpp)\n"
             "target_include_directories(dungeon_v45_logic_tests PRIVATE src)\n"
             "add_executable(travel_network_logic_tests")
replace_once("CMakeLists.txt",
             "inventory_filter_logic_tests dungeon_logic_tests travel_network_logic_tests)",
             "inventory_filter_logic_tests dungeon_logic_tests dungeon_v45_logic_tests travel_network_logic_tests)")
write("VERSION.txt", "4.5\n")
rc = read("resources/app.rc").replace("4,4,0,0", "4,5,0,0").replace('"4.4\\0"', '"4.5\\0"').replace("v4.4.exe", "v4.5.exe")
write("resources/app.rc", rc)

# Changelog/test-plan notes are additive and idempotent.
changelog = read("CHANGELOG.md")
section = """## v4.5 — Multi-phó-bản queue + live Activity board\n\n- Mỗi tổ đội có tên hiển thị, sửa thành viên/KEY và danh sách nhiều phó bản; mỗi dòng chạy 1–10 lượt.\n- Queue chạy tuần tự: chứng minh rời dungeon map → Telegram từng lượt → dùng chung Auto Sell → lượt/phó bản tiếp theo.\n- AUTO-ĐÁNH/DỪNG/WAIT có thể kế thừa tọa độ hợp lệ gần nhất phía trên cùng Map; START fail-closed nếu kế thừa không hợp lệ.\n- BẢNG HOẠT ĐỘNG PB đọc semantic text trực tiếp từ active client UI; không OCR và không dùng GMonster/STEP để bịa current/target.\n- Xuất/nhập toàn bộ cấu hình phó bản, RoleID bền vững; PID/HWND/snapshot/RUN state không được persist.\n- Các nút v4.5 có hàng riêng ở đáy tab; ghi chú an toàn được dời xuống, không chồng control.\n\n"""
if "## v4.5 — Multi-phó-bản queue + live Activity board" not in changelog:
    write("CHANGELOG.md", section + changelog)
plan = read("AUTO_DUNGEON_RUNTIME_TEST_PLAN.md")
plan_add = """\n\n## v4.5 queue / activity-board acceptance\n\n- Tạo đội 6 acc, đổi tên, đổi KEY, thêm/xóa thành viên khi STOP; QUÉT CLIENT lại và xác nhận RoleID bind sang PID mới.\n- Xếp ít nhất 2 phó bản với số lượt khác nhau; xác nhận từng lượt chỉ advance sau khi rời map + PostSell hoàn tất.\n- Kiểm tra Telegram chỉ gửi một thông báo cho mỗi tuple Team/Preset/Queue/Lượt.\n- Để X/Y của FIGHT bằng 0 và có MOVE hợp lệ phía trên cùng Map: scan radius phải dùng tọa kế thừa; khác Map phải fail-closed ở START.\n- Mở BẢNG HOẠT ĐỘNG PB: khi KEY đúng dungeon Map và UI có dòng current/target phải LIVE SYNC; đóng/ẩn dòng activity phải hiện CHƯA ĐỒNG BỘ, tuyệt đối không lấy số GMonster/STEP thay thế.\n- Xuất .tlpb, đổi cấu hình, nhập lại khi toàn bộ đội STOP; so sánh team name, RoleID, KEY, queue, preset override, monster catalog và sell threshold.\n- Kiểm tra hàng nút v4.5 ở y=930 và ghi chú An toàn ở y=966 không đè lên control khác.\n"""
if "## v4.5 queue / activity-board acceptance" not in plan:
    write("AUTO_DUNGEON_RUNTIME_TEST_PLAN.md", plan + plan_add)

# Persistent main workflow is rewritten to the v4.5 contract. The bootstrap workflow builds the
# branch once; after merge this workflow rebuilds/publishes main on every source change.
workflow = r'''name: Build v4.5 AUTO Thần Long đa tính năng Pro

on:
  workflow_dispatch:
  pull_request:
    branches:
      - main
  push:
    branches:
      - main
    paths:
      - '.github/workflows/build-v41.yml'
      - 'src/**'
      - 'tools/**'
      - 'resources/**'
      - 'CMakeLists.txt'
      - 'VERSION.txt'
      - 'README.md'
      - 'CHANGELOG.md'
      - 'AUTO_DUNGEON_RUNTIME_TEST_PLAN.md'

permissions:
  contents: write

jobs:
  build:
    runs-on: windows-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Verify v4.5 source contracts
        shell: powershell
        run: |
          python tools/verify_v152_clean.py
          if ($LASTEXITCODE -ne 0) { throw 'core verifier failed' }
          python tools/test_tlmaster_contract.py
          if ($LASTEXITCODE -ne 0) { throw 'TLMASTER verifier failed' }
          if ((Get-Content VERSION.txt -Raw).Trim() -ne '4.5') { throw 'VERSION.txt is not 4.5' }
          if (-not (Select-String -Path CMakeLists.txt -SimpleMatch 'project(ThanLongItemConsolidator VERSION 4.5' -Quiet)) { throw 'CMake project version is not 4.5' }
          if (-not (Select-String -Path resources/app.rc -SimpleMatch 'FILEVERSION 4,5,0,0' -Quiet)) { throw 'EXE VERSIONINFO is not 4.5' }
          if (Select-String -Path src/dungeon_app_methods.inl -Pattern 'requiredKills|DeathTracker|team\.kills|CountDiagnostic' -Quiet) { throw 'old dungeon kill-counter logic remains' }
          if (-not (Select-String -Path src/dungeon_app_methods.inl -SimpleMatch 'Elapsed(now, team.lastScanTick, 5000)' -Quiet)) { throw '5-second monster presence scan missing' }
          if (-not (Select-String -Path src/dungeon_app_methods.inl -SimpleMatch 'AUTO PHÓ BẢN: dùng core AUTO→ĐÁNH QUÁI của Tab AUTO' -Quiet)) { throw 'shared AUTO fight core missing' }
          if (-not (Select-String -Path src/controller.cpp -SimpleMatch 'EnterDungeonTabSafetyStop()' -Quiet)) { throw 'dungeon tab ownership safety missing' }
          if (-not (Select-String -Path src/dungeon_v45_methods.inl -SimpleMatch 'BẢNG HOẠT ĐỘNG PB' -Quiet)) { throw 'v4.5 activity board UI missing' }
          if (-not (Select-String -Path src/dungeon_activity_bridge.inl -SimpleMatch 'ACTIVITY LIVE_UI PASS' -Quiet)) { throw 'live activity observer missing' }
          if (-not (Select-String -Path src/protocol.h -SimpleMatch 'ReadDungeonActivityBoard = 28' -Quiet)) { throw 'activity-board bridge command missing' }
          if (-not (Select-String -Path src/dungeon_app_methods.inl -SimpleMatch 'DungeonV45NotifyRunComplete' -Quiet)) { throw 'per-run dungeon Telegram missing' }
          if (-not (Select-String -Path src/dungeon_app_methods.inl -SimpleMatch 'ValidateInheritedCoordinates' -Quiet)) { throw 'coordinate inheritance guard missing' }
          if (-not (Select-String -Path src/telegram_account_filter.cpp -SimpleMatch 'kTelegramTabIndex = 3' -Quiet)) { throw 'ACC BAO CAO tab ownership fix missing' }

      - name: Configure x64 Release
        shell: powershell
        run: |
          cmake -S . -B build -A x64
          if ($LASTEXITCODE -ne 0) { throw 'configure failed' }

      - name: Build x64 Release
        shell: powershell
        run: |
          cmake --build build --config Release --parallel
          if ($LASTEXITCODE -ne 0) { throw 'build failed' }

      - name: Run 15 logic tests
        shell: powershell
        run: |
          $tests=@(
            'route_logic_tests','rotation_logic_tests','trade_coordinator_logic_tests',
            'background_ui_logic_tests','fixed_slot_sell_logic_tests','unity_geometry_logic_tests',
            'internal_ui_click_logic_tests','travel_fight_guard_logic_tests','auto_fight_retry_logic_tests',
            'auto_pk_logic_tests','telegram_logic_tests','inventory_filter_logic_tests','dungeon_logic_tests',
            'dungeon_v45_logic_tests','travel_network_logic_tests'
          )
          foreach($t in $tests){
            $p=Join-Path 'build/Release' ($t+'.exe')
            if(!(Test-Path $p)){throw "missing $p"}
            & $p
            if($LASTEXITCODE -ne 0){throw "$t failed"}
          }

      - name: Stage v4.5 binaries and source
        shell: powershell
        run: |
          Remove-Item dist -Recurse -Force -ErrorAction SilentlyContinue
          New-Item -ItemType Directory -Force dist | Out-Null
          Copy-Item build/Release/ThanLongItemConsolidator.exe dist/AUTO_Than_Long_da_tinh_nang_Pro_v4.5.exe -Force
          Copy-Item build/Release/ThanLongCleanRouteBridge.dll dist/ThanLongCleanRouteBridge.dll -Force
          Compress-Archive -Path dist/AUTO_Than_Long_da_tinh_nang_Pro_v4.5.exe,dist/ThanLongCleanRouteBridge.dll -DestinationPath dist/AUTO-Than-Long-da-tinh-nang-Pro-v4.5-win-x64.zip -CompressionLevel Optimal -Force
          $sourceItems=@('.github','resources','src','tools','CMakeLists.txt','README.md','CHANGELOG.md','VERSION.txt','AUTO_DUNGEON_RUNTIME_TEST_PLAN.md','.gitignore')
          Compress-Archive -Path $sourceItems -DestinationPath dist/AUTO-Than-Long-da-tinh-nang-Pro-v4.5-source.zip -CompressionLevel Optimal -Force
          $items=@('dist/AUTO_Than_Long_da_tinh_nang_Pro_v4.5.exe','dist/ThanLongCleanRouteBridge.dll','dist/AUTO-Than-Long-da-tinh-nang-Pro-v4.5-win-x64.zip','dist/AUTO-Than-Long-da-tinh-nang-Pro-v4.5-source.zip')
          $lines=foreach($p in $items){$h=(Get-FileHash $p -Algorithm SHA256).Hash.ToLower();"$h  $([IO.Path]::GetFileName($p))"}
          $lines | Set-Content dist/SHA256SUMS.txt
          Get-Content dist/SHA256SUMS.txt

      - name: Upload v4.5 artifact
        uses: actions/upload-artifact@v4
        with:
          name: AUTO-Than-Long-da-tinh-nang-Pro-v4.5
          path: dist/*
          if-no-files-found: error

      - name: Publish clean v4.5 source and dist to main
        if: github.event_name == 'push' || github.event_name == 'workflow_dispatch'
        shell: powershell
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
          Remove-Item build -Recurse -Force -ErrorAction SilentlyContinue
          git checkout -- .github/workflows/build-v41.yml
          git add -A
          git add -f dist
          git reset -- .github/workflows/build-v41.yml
          git diff --cached --quiet
          if ($LASTEXITCODE -ne 0) {
            git commit -m "feat: AUTO Phó Bản v4.5 queue + live activity board [skip ci]"
            git push origin HEAD:main
            if ($LASTEXITCODE -ne 0) { throw 'publish v4.5 dist to main failed' }
          }
'''
write(".github/workflows/build-v41.yml", workflow)

print("v4.5 integration patch applied successfully")
